#define calloc __libc_calloc
#define malloc __libc_malloc

#include "calloc.c"
